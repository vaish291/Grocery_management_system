package com.db;
import java.sql.*;

public class ConnectDB {
	static Connection con = null;
	public static Connection getConnect()
	{
		try
		{
			if(con==null)
			{
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/grocery","root","");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}

}
