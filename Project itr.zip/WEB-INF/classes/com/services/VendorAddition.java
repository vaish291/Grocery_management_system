package com.services;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.ConnectDB;

/**
 * Servlet implementation class VendorAddition
 */
public class VendorAddition extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VendorAddition() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		 
	        String vendor_name = request.getParameter("vendor_name");
	        String vendor_contact = request.getParameter("vendor_contact");

	        try {
	            Connection con = ConnectDB.getConnect();
	            PreparedStatement ps = con.prepareStatement("select * from vendor where vendor_contact=?");
	            ps.setString(1, vendor_contact);
	            ResultSet rs = ps.executeQuery();
	            if(rs.next())
	            {
	            	response.sendRedirect("fail.html");
	            }
	            else
	            {
	            	PreparedStatement pstmt = con.prepareStatement("INSERT INTO vendor VALUES(?,?,?)");
		            pstmt.setInt(1, 0);
		            pstmt.setString(2, vendor_name);
		            pstmt.setString(3, vendor_contact);

		            int i = pstmt.executeUpdate();
		            if (i > 0) {
		                response.sendRedirect("Success.html"); // Success page
		            } else {
		                response.sendRedirect("fail.html"); // Failure page
		            }
	            }
	            
	            
	            
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		
	}

}
