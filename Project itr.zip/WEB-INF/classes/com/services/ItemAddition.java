package com.services;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.ConnectDB;

/**
 * Servlet implementation class ItemAddition
 */
public class ItemAddition extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ItemAddition() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String items_id = request.getParameter("items_id");
	    String items_name = request.getParameter("items_name");
	    String items_price = request.getParameter("items_price");
	    String items_quantity = request.getParameter("items_quantity");

	    try {
	        Connection con = ConnectDB.getConnect();

	        // Check if the item with the given ID already exists
	        PreparedStatement checkStmt = con.prepareStatement("SELECT * FROM items WHERE items_id = ?");
	        checkStmt.setString(1, items_id);
	        ResultSet resultSet = checkStmt.executeQuery();

	        if (resultSet.next()) {
	            // Item with the given ID already exists, update the quantity
	            PreparedStatement updateStmt = con.prepareStatement("UPDATE items SET items_quantity = ? WHERE items_id = ?");
	           // updateStmt.setInt(1, Integer.parseInt(items_quantity));
	            updateStmt.setString(1, items_quantity);
	            updateStmt.setString(2, items_id);
	            int updateResult = updateStmt.executeUpdate();

	            if (updateResult > 0) {
	                response.sendRedirect("Success.html"); 
	            } else {
	                response.sendRedirect("fail.html"); 
	            }
	        } else {
	            // Item with the given ID does not exist, insert a new item
	            PreparedStatement insertStmt = con.prepareStatement("INSERT INTO items (items_id,items_name, items_price, items_quantity) VALUES(?,?,?,?)");
	            insertStmt.setString(1, items_id);
	            insertStmt.setString(2, items_name);
	            insertStmt.setString(3, items_price);
	            insertStmt.setString(4, items_quantity);

	            int insertResult = insertStmt.executeUpdate();

	            if (insertResult > 0) {
	                response.sendRedirect("Success.html"); 
	            } else {
	                response.sendRedirect("fail.html"); 
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

}
