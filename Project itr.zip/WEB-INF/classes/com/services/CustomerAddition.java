package com.services;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.ConnectDB;

/**
 * Servlet implementation class CustomerAddition
 */
public class CustomerAddition extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerAddition() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		    String customer_id = request.getParameter("customer_id");
	        String customer_name = request.getParameter("customer_name");
	        String customer_contact = request.getParameter("customer_contact");

	        try {
	            Connection con = ConnectDB.getConnect();
	            PreparedStatement pstmt = con.prepareStatement("INSERT INTO customer(customer_id,customer_name,customer_contact) VALUES(?,?,?)");
	            pstmt.setString(1,customer_id);
	            pstmt.setString(2,customer_name);
	            
	            pstmt.setString(3,customer_contact);

	            int i = pstmt.executeUpdate();
	            if (i > 0) {
	                response.sendRedirect("Success.html"); // Success page
	            } else {
	                response.sendRedirect("fail.html"); // Failure page
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}

}
